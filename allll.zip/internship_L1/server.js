const express = require('express');
const app = express();
const port = 3000;

app.use(express.urlencoded({ extended: true }));

app.get('/', (req, res) => {
    res.render("index");
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
app.post('/submit-form', (req, res) => {
    const formData = req.body;
    console.log(formData);
    res.send('Form submitted successfully!');
});
app.set('view engine', 'ejs');
