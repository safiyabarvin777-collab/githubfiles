const form = document.getElementById('registrationForm');

form.addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form submission

    // Clear error messages
    document.querySelectorAll('.error').forEach(el => el.textContent = '');

    let isValid = true;

    // Name validation
    const name = document.getElementById('name').value.trim();
    if (name === "") {
        document.getElementById('nameError').textContent = "Name is required.";
        isValid = false;
    }

    // Email validation
    const email = document.getElementById('email').value.trim();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email) {
        document.getElementById('emailError').textContent = "Email is required.";
        isValid = false;
    } else if (!emailRegex.test(email)) {
        document.getElementById('emailError').textContent = "Invalid email format.";
        isValid = false;
    }

    // Country validation
    const country = document.getElementById('country').value;
    if (country === "") {
        document.getElementById('countryError').textContent = "Please select a country.";
        isValid = false;
    }

    if (isValid) {
        const formData = {
            name: name,
            email: email,
            country: country,
            bio: document.getElementById('bio').value.trim()
        };
        console.log("Form Data Submitted:", formData);
        alert("Form Submitted Successfully!");
    }
});