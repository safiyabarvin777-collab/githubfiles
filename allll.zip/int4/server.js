const express = require('express');
const app = express();
const port = 3000;

// Middleware to serve static files
app.use(express.static('public'));

// Middleware to parse JSON data
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Handle form submission
app.post('/submit-form', (req, res) => {
    const { name, email, country, bio } = req.body;

    // Server-side validation
    if (!name || !email || !country) {
        return res.status(400).send({ error: 'All fields except bio are required.' });
    }

    console.log("Server Received Data:", { name, email, country, bio });
    res.send({ message: 'Form submitted successfully!', data: { name, email, country, bio } });
});

// Start the server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});